﻿#ifndef CHESS_BOARD_H
#define CHESS_BOARD_H

#include "Shape.h"
#include "utils.h"
#include <cctype>
#include <cmath>
#include "Piece.h"

namespace Chess3D {
    class ChessBoard : public Shape {
    private:
        char board[8][8];
        bool pieceSelected = false;
        int selectedRow = -1;
        int selectedCol = -1;
        bool whiteTurn = true;

    public:
        ChessBoard(float x, float y, float z,
            float sx, float sy, float sz,
            float* diffColor, float* ambiColor, float* specColor);

        void initBoard();
        void drawBoard();
        void drawNumBoard();
        void drawSelection();
        void draw() override;
        void drawPieces();


        bool screenToBoardCell(int x, int y, int* outRow, int* outCol);

        bool isWhite(char piece) { return isupper(piece); }

        char getPiece(int row, int col) const {
            return board[row][col];
        }

        void setPiece(int row, int col, char piece) {
            board[row][col] = piece;
        }



    };
}

#endif
