﻿#include "ChessLogic.h"
#include <iostream>
#include <cmath>
#include <mutex>

namespace Chess3D {
    std::mutex boardMutex;

    ChessLogic::ChessLogic(ChessBoard* board)
        : board(board), whiteTurn(true), gameOver(false) {
    }

    bool ChessLogic::movePiece(int fromRow, int fromCol, int toRow, int toCol) {
        std::lock_guard<std::mutex> lock(boardMutex);

        if (gameOver) {
            std::cout << "Game over: " << resultMessage << "\n";
            return false;
        }

        char piece = board->getPiece(fromRow, fromCol);
        if (piece == ' ') {
            std::cout << "No piece at the selected position!\n";
            return false;
        }

        bool isWhite = isupper(piece);
        if (isWhite != whiteTurn) {
            std::cout << "It's the other player's turn!\n";
            return false;
        }

        if (!isValidMove(piece, fromRow, fromCol, toRow, toCol)) {
            std::cout << "Invalid move for piece " << piece << "\n";
            return false;
        }

        char targetPiece = board->getPiece(toRow, toCol);
        board->setPiece(toRow, toCol, piece);
        board->setPiece(fromRow, fromCol, ' ');

        if (isInCheck(isWhite)) {
            board->setPiece(fromRow, fromCol, piece);
            board->setPiece(toRow, toCol, targetPiece);
            std::cout << "This move leaves your king in check!\n";
            return false;
        }

        bool opponentIsWhite = !whiteTurn;
        if (isCheckmate(opponentIsWhite)) {
            gameOver = true;
            resultMessage = opponentIsWhite ? "Checkmate to White. Black wins!" : "Checkmate to Black. White wins!";
            std::cout << resultMessage << "\n";
        }

        whiteTurn = !whiteTurn;
        return true;
    }

    bool ChessLogic::isValidMove(char piece, int fromRow, int fromCol, int toRow, int toCol) {
        if (toRow < 0 || toRow >= 8 || toCol < 0 || toCol >= 8) return false;
        if (fromRow == toRow && fromCol == toCol) return false;

        char targetPiece = board->getPiece(toRow, toCol);
        if (targetPiece != ' ' &&
            ((isupper(piece) && isupper(targetPiece)) ||
                (islower(piece) && islower(targetPiece)))) {
            return false;
        }

        int rowDiff = toRow - fromRow;
        int colDiff = toCol - fromCol;
        int absRowDiff = abs(rowDiff);
        int absColDiff = abs(colDiff);

        switch (tolower(piece)) {
        case 'p': {
            int direction = isupper(piece) ? -1 : 1;
            int startRow = isupper(piece) ? 6 : 1;


            if (fromCol == toCol && targetPiece == ' ') {
                if (toRow == fromRow + direction) {
                    return true;
                }
                if (fromRow == startRow && toRow == fromRow + 2 * direction) {
                    if (board->getPiece(fromRow + direction, fromCol) == ' ') {
                        return true;
                    }
                }
                return false;
            }
            if (absColDiff == 1 && toRow == fromRow + direction && targetPiece != ' ') {
                return true;
            }
            return false;
        }

        case 'r':
            if ((fromRow == toRow || fromCol == toCol)) {
                return isPathClear(fromRow, fromCol, toRow, toCol);
            }
            return false;

        case 'n':
            return (absRowDiff == 2 && absColDiff == 1) || (absRowDiff == 1 && absColDiff == 2);

        case 'b':
            if (absRowDiff == absColDiff) {
                return isPathClear(fromRow, fromCol, toRow, toCol);
            }
            return false;

        case 'q':
            if ((fromRow == toRow || fromCol == toCol) || (absRowDiff == absColDiff)) {
                return isPathClear(fromRow, fromCol, toRow, toCol);
            }
            return false;

        case 'k': {
            // Обычный ход короля
            if (absRowDiff <= 1 && absColDiff <= 1) return true;

            // Рокировка: король двигается на 2 клетки по горизонтали
            if (absColDiff == 2 && rowDiff == 0) {
                int row = fromRow;
                bool isWhite = isupper(piece);
                int rookCol = (toCol == 6) ? 7 : 0; // короткая или длинная
                char rook = isWhite ? 'R' : 'r';

                // Проверка: ладья стоит на месте
                if (board->getPiece(row, rookCol) != rook) return false;

                // Клетки между королем и ладьей пусты?
                int start = std::min(fromCol, rookCol) + 1;
                int end = std::max(fromCol, rookCol) - 1;
                for (int col = start; col <= end; ++col) {
                    if (board->getPiece(row, col) != ' ') return false;
                }
                // Перемещение ладьи при рокировке
                if (tolower(piece) == 'k' && abs(toCol - fromCol) == 2) {
                    int rookFrom = (toCol == 6) ? 7 : 0;
                    int rookTo = (toCol == 6) ? 5 : 3;
                    char rook = isupper(piece) ? 'R' : 'r';

                    board->setPiece(toRow, rookTo, rook);
                    board->setPiece(toRow, rookFrom, ' ');
                }


                // Пропускаем проверку шаха (для упрощения). Можно добавить при желании.
                return true;
            }

            return false;
        }


        default:
            return false;
        }
    }

    bool ChessLogic::isPathClear(int fromRow, int fromCol, int toRow, int toCol) {
        int rowStep = (toRow > fromRow) ? 1 : (toRow < fromRow) ? -1 : 0;
        int colStep = (toCol > fromCol) ? 1 : (toCol < fromCol) ? -1 : 0;

        int currentRow = fromRow + rowStep;
        int currentCol = fromCol + colStep;

        while (currentRow != toRow || currentCol != toCol) {
            if (board->getPiece(currentRow, currentCol) != ' ') {
                return false;
            }
            currentRow += rowStep;
            currentCol += colStep;
        }
        return true;
    }

    bool ChessLogic::isInCheck(bool isWhite) {
        int kingRow = -1, kingCol = -1;
        char king = isWhite ? 'K' : 'k';

        for (int row = 0; row < 8; ++row) {
            for (int col = 0; col < 8; ++col) {
                if (board->getPiece(row, col) == king) {
                    kingRow = row;
                    kingCol = col;
                    break;
                }
            }
            if (kingRow != -1) break;
        }

        for (int row = 0; row < 8; ++row) {
            for (int col = 0; col < 8; ++col) {
                char piece = board->getPiece(row, col);
                if (piece != ' ' && (bool(isupper(piece)) != isWhite)) {
                    if (isValidMove(piece, row, col, kingRow, kingCol)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    bool ChessLogic::isCheckmate(bool isWhite) {
        if (!isInCheck(isWhite)) return false;

        for (int fromRow = 0; fromRow < 8; ++fromRow) {
            for (int fromCol = 0; fromCol < 8; ++fromCol) {
                char piece = board->getPiece(fromRow, fromCol);
                if (piece != ' ' && (isupper(piece) == static_cast<int>(isWhite))) {
                    for (int toRow = 0; toRow < 8; ++toRow) {
                        for (int toCol = 0; toCol < 8; ++toCol) {
                            if (isValidMove(piece, fromRow, fromCol, toRow, toCol)) {
                                char target = board->getPiece(toRow, toCol);
                                board->setPiece(toRow, toCol, piece);
                                board->setPiece(fromRow, fromCol, ' ');


                                bool stillInCheck = isInCheck(isWhite);

                                board->setPiece(fromRow, fromCol, piece);
                                board->setPiece(toRow, toCol, target);

                                if (!stillInCheck) {
                                    return false;
                                }
                            }
                        }
                    }
                }
            }
        }

        return true;
    }

    bool ChessLogic::isGameOver() const {
        return gameOver;
    }

    std::string ChessLogic::getResultMessage() const {
        return resultMessage;
    }

}
