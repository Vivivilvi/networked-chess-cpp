//#pragma once
//
//class PawnLogic {
//public:
//    static bool isValidMove(int fromRow, int fromCol, int toRow, int toCol, char board[8][8]);
//};
