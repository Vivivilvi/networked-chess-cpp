//#pragma once
//
//namespace Chess3D {
//    class PieceRenderer {
//    public:
//        static void renderPawn(bool isWhite);
//        static void renderRook(bool isWhite);
//        static void renderKnight(bool isWhite);
//        static void renderBishop(bool isWhite);
//        static void renderQueen(bool isWhite);
//        static void renderKing(bool isWhite);
//    };
//}
