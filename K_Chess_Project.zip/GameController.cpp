﻿//#include <glut.h>  // подключаем OpenGL
//#include "GameController.h"
//#include "ChessBoard.h"
//#include "Shape.h"
//#include <iostream>
//
//namespace Chess3D {
//
//    GameController::GameController(ChessBoard& board) : board(board) {}
//
//    void GameController::handleRightClick(int x, int y) {
//        int col = x / 100;
//        int row = 7 - (y / 100); // инверсия оси Y для OpenGL
//
//        std::cout << "Right click on row: " << row << ", col: " << col << "\n";
//
//        if (row >= 0 && row < 8 && col >= 0 && col < 8) {
//            // Простейший автопереход пешки вперед
//            int newRow = row + (whiteTurn ? 1 : -1);
//            if (newRow >= 0 && newRow < 8 && board.getPiece(row, col) != ' ') {
//                makeMove(row, col, newRow, col);
//                whiteTurn = !whiteTurn;
//            }
//        }
//    }
//
//    bool GameController::tryMove(int fromRow, int fromCol, int toRow, int toCol) const {
//        if (fromRow < 0 || fromRow >= 8 || fromCol < 0 || fromCol >= 8) return false;
//        if (toRow < 0 || toRow >= 8 || toCol < 0 || toCol >= 8) return false;
//        return true;
//    }
//
//    void GameController::makeMove(int fromRow, int fromCol, int toRow, int toCol) {
//        char piece = board.getPiece(fromRow, fromCol);
//        board.setPiece(toRow, toCol, piece);
//        board.setPiece(fromRow, fromCol, ' ');
//    }
//
//    // Добавляем обработчик клика мыши с преобразованием координат OpenGL
//    void GameController::onMouseClick(int mouseX, int mouseY) {
//        GLint viewport[4];
//        GLdouble modelview[16], projection[16];
//        GLfloat winX, winY, winZ;
//        GLdouble posX, posY, posZ;
//
//        glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
//        glGetDoublev(GL_PROJECTION_MATRIX, projection);
//        glGetIntegerv(GL_VIEWPORT, viewport);
//
//        winX = (float)mouseX;
//        winY = (float)viewport[3] - (float)mouseY; // OpenGL перевёрнуто по Y
//        glReadPixels(mouseX, (int)winY, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &winZ);
//        gluUnProject(winX, winY, winZ, modelview, projection, viewport, &posX, &posY, &posZ);
//
//        // Получаем параметры доски
//        float tileSize = board.getSX() / 8.0f;
//        float boardX = board.getX();
//        float boardZ = board.getZ();
//
//        // Вычисляем выбранный столбец и строку
//        int col = (int)round((posX - (boardX - (tileSize * 4))) / tileSize);
//        int row = (int)round((posZ - (boardZ - (tileSize * 4))) / tileSize);
//
//        if (row >= 0 && row < 8 && col >= 0 && col < 8) {
//            selectedRow = row;
//            selectedCol = col;
//            std::cout << "Selected cell: row " << row << ", col " << col << std::endl;
//        }
//        else {
//            selectedRow = selectedCol = -1;
//        }
//    }
//
//}
//
////#include <glut.h>  // подключаем OpenGL
////#include "GameController.h"
////#include "ChessBoard.h"
////#include <iostream>
////
////namespace Chess3D {
////    GameController::GameController(ChessBoard& board) : board(board) {}
////
////    void GameController::handleRightClick(int x, int y) {
////        int col = x / 100;
////        int row = 7 - (y / 100); // инверсия оси Y для OpenGL
////
////        std::cout << "Right click on row: " << row << ", col: " << col << "\n";
////
////        if (row >= 0 && row < 8 && col >= 0 && col < 8) {
////            // Простейший автопереход пешки вперед
////            int newRow = row + (whiteTurn ? 1 : -1);
////            if (newRow >= 0 && newRow < 8 && board.getPiece(row, col) != ' ') {
////                makeMove(row, col, newRow, col);
////                whiteTurn = !whiteTurn;
////            }
////        }
////    }
////
////    bool GameController::tryMove(int fromRow, int fromCol, int toRow, int toCol) const {
////        if (fromRow < 0 || fromRow >= 8 || fromCol < 0 || fromCol >= 8) return false;
////        if (toRow < 0 || toRow >= 8 || toCol < 0 || toCol >= 8) return false;
////        return true;
////    }
////
////    void GameController::makeMove(int fromRow, int fromCol, int toRow, int toCol) {
////        char piece = board.getPiece(fromRow, fromCol);
////        board.setPiece(toRow, toCol, piece);
////        board.setPiece(fromRow, fromCol, ' ');
////    }
////}
////
////
////
//////#include <glut.h>
//////#include "GameController.h"
//////#include "ChessBoard.h"
//////#include "Scene.h"
//////#include <cmath>
//////
//////namespace Chess3D {
//////
//////    bool GameController::tryMove(int fromRow, int fromCol, int toRow, int toCol) const {
//////        if (!board.isValidPosition(toRow, toCol)) return false;
//////
//////        char piece = board.board[fromRow][fromCol];
//////        char target = board.board[toRow][toCol];
//////
//////        // Нельзя бить свои фигуры
//////        if (target != ' ' && board.isWhite(piece) == board.isWhite(target))
//////            return false;
//////
//////        int dr = toRow - fromRow;
//////        int dc = toCol - fromCol;
//////
//////        piece = std::tolower(piece); // Чтобы не различать цвет
//////
//////        switch (piece) {
//////        case 'p': // Пешка
//////            return tryMovePawn(fromRow, fromCol, toRow, toCol, board.board[fromRow][fromCol]);
//////        case 'r': // Тура
//////            if (dr == 0 || dc == 0) {
//////                int stepRow = (dr == 0) ? 0 : (dr > 0 ? 1 : -1);
//////                int stepCol = (dc == 0) ? 0 : (dc > 0 ? 1 : -1);
//////                int r = fromRow + stepRow, c = fromCol + stepCol;
//////                while (r != toRow || c != toCol) {
//////                    if (board.board[r][c] != ' ') return false;
//////                    r += stepRow;
//////                    c += stepCol;
//////                }
//////                return true;
//////            }
//////            return false;
//////        case 'n': // Кінь
//////            return (std::abs(dr) == 2 && std::abs(dc) == 1) || (std::abs(dr) == 1 && std::abs(dc) == 2);
//////        case 'b': // Слон
//////            if (std::abs(dr) == std::abs(dc)) {
//////                int stepRow = (dr > 0) ? 1 : -1;
//////                int stepCol = (dc > 0) ? 1 : -1;
//////                int r = fromRow + stepRow, c = fromCol + stepCol;
//////                while (r != toRow && c != toCol) {
//////                    if (board.board[r][c] != ' ') return false;
//////                    r += stepRow;
//////                    c += stepCol;
//////                }
//////                return true;
//////            }
//////            return false;
//////        case 'q': // Ферзь
//////            if (dr == 0 || dc == 0 || std::abs(dr) == std::abs(dc)) {
//////                int stepRow = (dr == 0) ? 0 : (dr > 0 ? 1 : -1);
//////                int stepCol = (dc == 0) ? 0 : (dc > 0 ? 1 : -1);
//////                int r = fromRow + stepRow, c = fromCol + stepCol;
//////                while (r != toRow || c != toCol) {
//////                    if (board.board[r][c] != ' ') return false;
//////                    r += stepRow;
//////                    c += stepCol;
//////                }
//////                return true;
//////            }
//////            return false;
//////        case 'k': // Король
//////            return std::abs(dr) <= 1 && std::abs(dc) <= 1;
//////        default:
//////            return false;
//////        }
//////    }
//////
//////
//////    bool GameController::tryMovePawn(int fromRow, int fromCol, int toRow, int toCol, char piece) const {
//////        int dir = board.isWhite(piece) ? -1 : 1;  // белые ходят вверх (уменьшая row)
//////        int startRow = board.isWhite(piece) ? 6 : 1;
//////
//////        int rowDiff = toRow - fromRow;
//////        int colDiff = std::abs(toCol - fromCol);
//////
//////        if (colDiff == 0) {
//////            if (rowDiff == dir && board.board[toRow][toCol] == ' ')
//////                return true;
//////            if (fromRow == startRow && rowDiff == 2 * dir &&
//////                board.board[fromRow + dir][fromCol] == ' ' &&
//////                board.board[toRow][toCol] == ' ')
//////                return true;
//////        }
//////        else if (colDiff == 1 && rowDiff == dir) {
//////            if (board.board[toRow][toCol] != ' ' &&
//////                board.isWhite(board.board[toRow][toCol]) != board.isWhite(piece))
//////                return true;
//////        }
//////        return false;
//////    }
//////
//////    void GameController::makeMove(int fromRow, int fromCol, int toRow, int toCol) {
//////        board.board[toRow][toCol] = board.board[fromRow][fromCol];
//////        board.board[fromRow][fromCol] = ' ';
//////    }
//////}
