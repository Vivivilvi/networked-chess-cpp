﻿//#include "PieceRenderer.h"
//#include <glut.h>
//
//namespace Chess3D {
//    void PieceRenderer::renderPawn(bool isWhite) {
//        glColor3f(isWhite ? 1.0f : 0.2f, isWhite ? 1.0f : 0.2f, isWhite ? 1.0f : 0.2f);
//        glutSolidSphere(0.05, 20, 20);
//    }
//
//    // Остальные фигуры можно временно заглушить:
//    void PieceRenderer::renderRook(bool w) {}
//    void PieceRenderer::renderKnight(bool w) {}
//    void PieceRenderer::renderBishop(bool w) {}
//    void PieceRenderer::renderQueen(bool w) {}
//    void PieceRenderer::renderKing(bool w) {}
//}
