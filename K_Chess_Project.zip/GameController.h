﻿//#ifndef GAME_CONTROLLER_H
//#define GAME_CONTROLLER_H
//
//#include "ChessBoard.h"
//
//namespace Chess3D {
//    class GameController {
//    private:
//        ChessBoard& board;
//        bool whiteTurn = true;
//
//        // Добавь сюда переменные для выбранной клетки
//        int selectedRow = -1;
//        int selectedCol = -1;
//
//    public:
//        explicit GameController(ChessBoard& board);
//
//        void handleRightClick(int x, int y);
//        bool tryMove(int fromRow, int fromCol, int toRow, int toCol) const;
//        void makeMove(int fromRow, int fromCol, int toRow, int toCol);
//
//        void onMouseClick(int mouseX, int mouseY);
//    };
//}
//
//#endif
//
//
////#ifndef GAME_CONTROLLER_H
////#define GAME_CONTROLLER_H
////
////#include "ChessBoard.h"
////
////namespace Chess3D {
////    class GameController {
////    private:
////        ChessBoard& board;
////        bool whiteTurn = true;
////
////    public:
////        explicit GameController(ChessBoard& board);
////
////        void handleRightClick(int x, int y);
////        bool tryMove(int fromRow, int fromCol, int toRow, int toCol) const;
////        void makeMove(int fromRow, int fromCol, int toRow, int toCol);
////
////        void onMouseClick(int mouseX, int mouseY);
////    };
////}
////
////#endif
////
////
//////#ifndef GAME_CONTROLLER_H
//////#define GAME_CONTROLLER_H
//////
//////#include "ChessBoard.h"
//////
//////namespace Chess3D {
//////    class GameController {
//////    private:
//////        ChessBoard& board;
//////        bool whiteTurn = true;
//////
//////    public:
//////        explicit GameController(ChessBoard& board);
//////
//////        void handleRightClick(int x, int y);
//////        bool tryMove(int fromRow, int fromCol, int toRow, int toCol) const;
//////        bool tryMovePawn(int fromRow, int fromCol, int toRow, int toCol, char piece) const;
//////        void makeMove(int fromRow, int fromCol, int toRow, int toCol);
//////    };
//////}
//////
//////#endif
